// const baseURL = "https://crm.funstay.in/crmbackend"; 

// const webhookUrl = "https://crm.funstay.in";

const baseURL = "http://localhost:5000"; 
const webhookUrl = "http://localhost:4000";
const adminMail = "admin"

// Export them as named exports
export { baseURL, webhookUrl,adminMail };